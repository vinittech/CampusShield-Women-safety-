@echo off
title CampusShield - Public Internet Link Generator
echo ========================================================
echo   CampusShield - Public Internet Sharing Link Generator
echo ========================================================
echo.
echo Creating secure HTTPS public link accessible on any device anywhere in the world...
echo.
ssh -tt -o StrictHostKeyChecking=no -R 80:localhost:8080 nokey@localhost.run
pause
